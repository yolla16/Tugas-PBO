/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
import java.util.Scanner;

public class bilangan_ganjil_genap {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       
       System.out.println("Menentukan Bilangan Ganjil dan Genap");
       
       System.out.println("Masukkan Angka: ");
       int angka = input.nextInt();
       
       if (angka % 2 == 0) {
           System.out.println("Angka : "+ angka + " Bilangan Genap");
           
       }else{
           System.out.println("Angka : "+ angka + " Bilangan Ganjil");
       }
    }
    
}
