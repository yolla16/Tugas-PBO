/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Mahasiswa{
    String nama;
    String NIM;
    String Jurusan;
    double IP;
    int umur;
}
/**
 *
 * @author ASUS
 */
public class membuat_object {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // instansiasi/ membuat object
        Mahasiswa mahasiswal = new Mahasiswa();
        mahasiswal.nama = "Ariana";
        mahasiswal.NIM = "1235678";
        mahasiswal.Jurusan = "Teknologi Informasi";
        mahasiswal.IP = 4.0;
        mahasiswal.umur = 19;
        
        System.out.println(mahasiswal.nama);
        System.out.println(mahasiswal.NIM);
        System.out.println(mahasiswal.Jurusan);
        System.out.println(mahasiswal.IP);
        System.out.println(mahasiswal.umur);        
    }
    
}