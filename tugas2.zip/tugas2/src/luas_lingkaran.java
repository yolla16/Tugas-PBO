/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class luas_lingkaran {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int r = 10;
        double luas = 3.14 * r * r;
        
        System.out.println("masukkan jari-jari = "+r);
        System.out.println("Luas lingkaran = "+luas);
    }
    
}
