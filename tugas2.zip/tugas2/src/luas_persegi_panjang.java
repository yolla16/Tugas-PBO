/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class luas_persegi_panjang {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int p = 12;
        int l = 10;
        double luas = p * l;
        
        System.out.println("masukkan panjang = "+p);
        System.out.println("masukkan lebar = "+l);
        System.out.println("Hasil Luas persegi panjang = "+luas);
    }
    
}
