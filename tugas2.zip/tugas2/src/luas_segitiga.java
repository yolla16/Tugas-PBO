/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class luas_segitiga {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int a = 9;
        int t =21;
        double luas = 0.5 * a * t;
        
        System.out.println("masukkan alas = "+a);
        System.out.println("masukkan alas = "+t);
        System.out.println("Hasil = "+luas);
    }
    
}
